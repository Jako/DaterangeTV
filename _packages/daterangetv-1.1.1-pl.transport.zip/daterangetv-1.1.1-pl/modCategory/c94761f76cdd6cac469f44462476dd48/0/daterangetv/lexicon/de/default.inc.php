<?php
/**
 * Default German Lexicon Entries for daterange
 *
 * @package daterangetv
 * @subpackage lexicon
 */
$_lang['daterange'] = 'Daterange';
