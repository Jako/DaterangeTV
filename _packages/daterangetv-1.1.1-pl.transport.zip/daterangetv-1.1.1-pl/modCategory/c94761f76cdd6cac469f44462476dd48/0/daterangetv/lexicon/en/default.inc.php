<?php
/**
 * Default English Lexicon Entries for daterange
 *
 * @package daterangetv
 * @subpackage lexicon
 */
$_lang['daterange'] = 'Daterange';
