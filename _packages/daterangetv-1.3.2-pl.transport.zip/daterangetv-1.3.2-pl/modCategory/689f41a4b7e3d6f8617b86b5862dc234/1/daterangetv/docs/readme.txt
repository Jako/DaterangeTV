DaterangeTV
===========

Date range custom template variable for MODX Revolution.

Features
--------

With this MODX Revolution custom template variable two depending date inputs 
could be used to insert a date range in a MODX resource.

Installation
------------
MODX Package Management

Documentation
-------------
http://jako.github.io/DaterangeTV/

GitHub Repository
-----------------
https://github.com/Jako/DaterangeTV
