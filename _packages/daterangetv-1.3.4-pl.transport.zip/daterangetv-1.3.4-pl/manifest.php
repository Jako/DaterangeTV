<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'daterangetv-1.3.4-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ed752e6c1b4bc5df837062b6623f1bbc',
      'native_key' => 'daterangetv',
      'filename' => 'modNamespace/ec421de028b334cb00fdc6de2c15d284.vehicle',
      'namespace' => 'daterangetv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57cd4dd783e6d421ecde0440cb21621f',
      'native_key' => 'daterangetv.format',
      'filename' => 'modSystemSetting/a2295237698ab8c14ddbb4d435bc12df.vehicle',
      'namespace' => 'daterangetv',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd06e9a5f02a51a6a74a542e03b1056a5',
      'native_key' => 'daterangetv.manager_format',
      'filename' => 'modSystemSetting/396808fe17d9e91698da586f5b6b4189.vehicle',
      'namespace' => 'daterangetv',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '254d1f830ff08ab53c4a8a9dd101269f',
      'native_key' => 'daterangetv.separator',
      'filename' => 'modSystemSetting/e7bcf3c780412f2af171f114221b2602.vehicle',
      'namespace' => 'daterangetv',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a4ddde6465d76240033d1660e0fc102d',
      'native_key' => NULL,
      'filename' => 'modCategory/0f7102dc246a6cb81c59be996ae4cfa3.vehicle',
      'namespace' => 'daterangetv',
    ),
  ),
);