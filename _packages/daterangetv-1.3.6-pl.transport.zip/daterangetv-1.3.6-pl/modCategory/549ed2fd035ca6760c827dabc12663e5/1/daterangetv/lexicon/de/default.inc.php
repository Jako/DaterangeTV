<?php
/**
 * Default Lexicon Entries for DaterangeTV
 *
 * @package daterangetv
 * @subpackage lexicon
 */

$_lang['daterange'] = 'Datumsbereich';

$_lang['daterangetv.none'] = 'keine';
