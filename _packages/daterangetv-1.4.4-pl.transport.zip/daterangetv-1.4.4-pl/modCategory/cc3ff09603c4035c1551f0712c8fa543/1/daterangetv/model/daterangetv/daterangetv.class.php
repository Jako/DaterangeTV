<?php
/**
 * Main Class for DaterangeTV
 *
 * Copyright 2013-2023 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package daterangetv
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class DaterangeTV
 */
class DaterangeTV extends \TreehillStudio\DaterangeTV\DaterangeTV
{
}
